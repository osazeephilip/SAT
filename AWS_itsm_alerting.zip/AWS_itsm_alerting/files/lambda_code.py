import json
import os
from urllib3 import PoolManager

# ITSM configuration
itsm_api_url = os.getenv('itsm_api_url')
mc_id = os.getenv('mc_id')
origin = os.getenv('origin')
severity = os.getenv('severity')
ars_delay_time = int(os.getenv('ars_delay_time'))
dry_run = json.loads(os.getenv('dry_run').lower())
api_key = os.getenv('api_key')
event_id = int(os.getenv('event_id', '80123'))


def lambda_handler(event, context):

    # print sns event
    print(json.dumps(event))

    message = json.loads(event["Records"][0]["Sns"]["Message"])

    # CloudWatch Alarm Parsing
    if 'AlarmName' in message:
        sub_source = message["AlarmArn"]
        sub_origin = message["AWSAccountId"]

    # CloudWatch Event Parsing
    if 'detail-type' in message:
        sub_source = message["resources"][0]
        sub_origin = message["account"]

    # CloudWatch RDS Event Parsing
    if 'Event ID' in message:
        if 'RDS-EVENT-' in message['Event ID']:
            sub_source = message["Source ARN"]
            sub_origin = sub_source.split(":")[4]

    # Message formatting
    message = json.dumps(message)[:2048]
    encoded_msg = json.dumps({
        "contract_id": mc_id,
        "event_id": event_id,
        "message": message,
        "origin": origin,
        "sub_origin": sub_origin,
        "sub_source": sub_source,
        "severity": severity,
        "ars_delay_time": ars_delay_time,
        "dry_run": dry_run
    })

    # Request
    http = PoolManager()
    resp = http.request('POST',
                        itsm_api_url,
                        headers={'x-api-key': api_key},
                        body=encoded_msg
                        )

    # Logging
    print({
        "status_code": resp.status,
        "response": resp.data
    })
