# ITSM Ticket Service based on a SNS Topic and Lambda function

<!--cna-default-test-start-->
[![CNA repo](https://img.shields.io/static/v1?logo=git&style=plastic&label=CNA%20repo&message=✓%2012%20|✗%200%20|▲%200|➝%200&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-itsm-alerting/actions/runs/1818640)
[![TF Base](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=TF%20Base&message=✓%203%20|✗%200%20|▲%200|➝%200&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-itsm-alerting/actions/runs/1818640)
[![TF Compliance (tflint)](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=TF%20Compliance%20(tflint)&message=✓%20Success&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-itsm-alerting/actions/runs/1818640)
[![Security (Checkov)](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=Security%20(Checkov)&message=✓%2071%20|✗%200%20|▲%2015|➝%200&color=yellow)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-itsm-alerting/actions/runs/1818640)
<!--cna-default-test-end-->

![CNA Hero Image](./images/cna_github_social_700.png)

## Description

This module helps to create ITSM incident tickets based on Cloudwatch alarm or events which are created within your AWS account.

The module sets up a Lambda function and an SNS topic using the [SNS module](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-sns).

You have to configure your own CloudWatch events/alarms as well as the forwarding of these events to the SNS topic.

If the topic receives messages, they are forwarded to a Lamdbda function.
The Lambda function holds your ITSM configuration, parses the events/alarm messages and triggers the [AWS ITSM Event Bridge API](https://developer.bmwgroup.net/docs/public-cloud-platform-aws/3_runyourapplication/monitoring_and_alerting/itsm_gateway/itsm_gateway/#overview), which is provided by the BMW FPC team.
By default, the module creates a new SNS topic, but an existing SNS topic can be used as well.

**Attention:** Please be aware, that a misconfiguration of alarms may lead to a very high amount of ITSM tickets for your application.

## Prerequisites

-   Fully configured BMW AWS Cloud Room
-   Service Principal for this Cloud Room
-   Latest Terraform Version (>= 1.1.5) [Download](https://www.terraform.io/downloads)
-   Possibility to run Bash scripts (Linux OS, WSL2, Cygwin)
-   You have read the READMEs and the comments in main.tf and variables.tfvars
-   You have adjusted the configuration to **your** cloud room
-   You created a Monitoring Contract ID and configured an ITSM Bridge. For more detailed information on how to do this, please refer to the chapter "How to configure the module for this scenario" in the [examples' readme files](examples/10-simple/README.md#preparation-monitoring-contract-id-and-itsm-bridge-configuration).

## What is supported?

- Creating ITSM tickets based on AWS event notifications and alerts
- Data in use encryption for the Lambda function created by this module. Just set the `architectures` variable to `["arm64"]` to make use of this feature. The usage is demonstrated in both examples.
- Lamda function, Cloudwatch log group and SNS topic created by this module can use customer managed KMS keys for encryption. It is even possible to configure different keys for the SNS topic on the one side and Lambda and Cloudwatch on the other.
  - Usage of customer managed keys is demonstrated in examples 10 and 40.

## Examples

We have created the following examples to show how this module could be used in your architecture. Please find a detailed description in the examples' READMEs.

- [simple example: ITSM alerting with customer managed KMS key](examples/10-simple/)
- [SF hardened example: ITSM alerting with customer managed KMS key](examples/40-sf-hardened/)

### Run the examples

To be able to try out the example within a few minutes, we've written a small bash script './examples/local_tf_run.sh'.
This will enable to experiment with the module, understand it in detail and use it in your architecture.

>  Be aware, that your Terraform state with credentials will be
> stored locally on your machine!
>
> **DO NOT** use this in production scenarios, just for local testing!

#### Good to know

-   [How to run the Examples](https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/faq/general-faq/#how-to-run-the-examples-with-the-bash-script)
-   [How to authenticate to your Cloud Room](https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/faq/general-faq/#how-to-enable-azure-aws-authentication)
-   [How to authenticate to the Source Code Management to download modules](https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/faq/general-faq/#source-code-management-scm-authentication)
-   [How to prepare my local development environment](https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/faq/general-faq/#how-to-set-up-your-local-development-environment)


## Where to find help?

If you have questions or problems deploying this module, please check if there have been similar issues which may have
addressed your problem already.

Please feel free to join the Cloud Walk-in Sessions our the Cloud Architecture Hours:

-   [Book a slot for a Walk-in Session](https://atc.bmwgroup.net/confluence/display/ITLAB/Skype+Walk-In+Session%3A+Cloud)
-   [Book a slot for a Cloud Architecture Hour](https://atc.bmwgroup.net/confluence/display/ITLAB/Cloud+Architecture+Hours)

## Responsibilities

The below team is responsible for this repo, but everyone is welcome to contribute (e.g. by creating a Pull Request). More information to the process can be found [here](https://developer.bmwgroup.net/docs/cloud-guides-and-best-practices/20_gettingstarted/guidelines/terraform-modules/).

| Team in charge | Date from     | Date to       |
| -------------- | ------------- | ------------- |
| FG-242         | 20 Oct 2021   | today         |

## terraform-docs
Please find a detailed technical documentation of the root module in the [MODULE.md](MODULE.md).