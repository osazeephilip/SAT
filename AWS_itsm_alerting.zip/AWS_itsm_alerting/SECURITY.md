## Security.md

Building Block: terraform-aws-bmw-alerting

Restrictions in Scope: Tag 2.1.12 was evaluated

Evaluation Date: 2022-08-09 by FG\-15-CSAE

Date of last Change of Building Block: 2022-07-22


## Security Capabilities of the Building Block

Short summary of the security properties of the solution and its components, in order of the Security Capabilities / Best Practices.

### Authentication and Authorization (User, Tech Identities, Access Control)

* A baseline Access Control is applied to have at least a baseline protection.

### Encryption (at Rest and in Transit, Key Mgmt, Certificates)

* Encryption at transit in this building block is ensured by the AWS network since only AWS native services are used.
* Encryption between Lambda and ITSM or MS/Teams is ensured by HTTPS enabled on the destination side.
* Encryption at rest in SNS and in Lambda(e.g. environment variables) is ensured by KMS.

### Operations (Vulnerabilites, Hardening, Availability)
* Back-Up of Lambda function is ensured by the version control system
* Lambda execution logs are stored in Cloudwatch

### Additional Security Functionality

* The building block is meant as an alerting mechanism as part of an monitoring architecture 

## Security Requirements to be considered by devops teams

The DevOps Team has to consider these additional requirements which are not (completely) covered by the building block.

### Authentication and Authorization (User, Tech Identities, Access Control)
Ensure that a SNS policy via the variable sns_policy to have a more restrictive access to the SNS beyond the policy used in the building block (all principals in AWS account)

Ensure that the IAM policies used for managing Cloudwatch Alarms, SNS topics and Lambda are restricted to not allow disable/remove actions for all principals.

### Operations (Vulnerabilites, Hardening, Availability)
Refer to the ITSM solution instead of the MS/Teams solution because the ITSM solution offers more access and DoS Protection and a more reliable throughput. MS/Teams Webhook accepts every message without any authorization, over the Internet.

Ensure that the Lambda logs are regularly queried to check for sensitive information.

### Additional Security Functionality
Consider the configuration of reserved concurrency (when highly dependent of the alerting module and a lot of Lambda functions are used).

Consider a deadletter queue is configured in Lambda to prevent loss of potential important alarms.

Ensure that the Lambda retries are adequately configured (>2 retries) to prevent loss of information.