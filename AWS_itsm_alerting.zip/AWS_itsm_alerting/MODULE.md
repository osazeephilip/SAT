<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.3 |
| <a name="requirement_archive"></a> [archive](#requirement\_archive) | 2.4.0 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | >= 4.11 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_archive"></a> [archive](#provider\_archive) | 2.4.0 |
| <a name="provider_aws"></a> [aws](#provider\_aws) | 5.5.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_common"></a> [common](#module\_common) | git::https://atc-github.azure.cloud.bmw/cgbp/terraform-bmw-cloud-commons.git | 2.1.6 |
| <a name="module_itsm_topic"></a> [itsm\_topic](#module\_itsm\_topic) | git::https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-sns.git | 3.0.0 |

## Resources

| Name | Type |
|------|------|
| [aws_cloudwatch_log_group.itsm_alerting_log_group](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudwatch_log_group) | resource |
| [aws_iam_policy.lambda_logging](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_policy) | resource |
| [aws_iam_role.itsm_lambda_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) | resource |
| [aws_iam_role_policy_attachment.lambda_logs](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy_attachment) | resource |
| [aws_lambda_function.itsm_lambda_function](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lambda_function) | resource |
| [aws_lambda_permission.allow_cloudwatch](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lambda_permission) | resource |
| [aws_sns_topic_subscription.itsm_topic_subscription](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/sns_topic_subscription) | resource |
| [archive_file.itsm_lambda_code_zip_file](https://registry.terraform.io/providers/hashicorp/archive/2.4.0/docs/data-sources/file) | data source |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_iam_policy_document.itsm_lambda_assume_role_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_iam_policy_document.sns-topic-policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_kms_key.key_by_id](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/kms_key) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_architectures"></a> [architectures](#input\_architectures) | Instruction set architecture for your Lambda function. Valid values are 'x86\_64' and 'arm64' | `list(string)` | <pre>[<br>  "x86_64"<br>]</pre> | no |
| <a name="input_ars_delay_time"></a> [ars\_delay\_time](#input\_ars\_delay\_time) | Time in seconds until event will be forwarded to ITSM. Default at IT Event Management is 900 seconds/15 minutes. | `number` | `900` | no |
| <a name="input_cloud_region"></a> [cloud\_region](#input\_cloud\_region) | define the location which tf should use. | `string` | n/a | yes |
| <a name="input_commons_file_json"></a> [commons\_file\_json](#input\_commons\_file\_json) | Json file to override the commons fixed variables. | `string` | `""` | no |
| <a name="input_cost_tag_1"></a> [cost\_tag\_1](#input\_cost\_tag\_1) | COST TAG 1 used for cost allocation, see https://developer.bmw.com/docs/public-cloud-platform-aws/3_runyourapplication/cost_management/cost_tag/cost_allocation_tag/ | `string` | `""` | no |
| <a name="input_cost_tag_2"></a> [cost\_tag\_2](#input\_cost\_tag\_2) | COST TAG 1 used for cost allocation, see https://developer.bmw.com/docs/public-cloud-platform-aws/3_runyourapplication/cost_management/cost_tag/cost_allocation_tag/ | `string` | `""` | no |
| <a name="input_create_sns_topic"></a> [create\_sns\_topic](#input\_create\_sns\_topic) | when true, create a new SNS topic instead of using the SNS topic given in variable `sns_topic_arn`. | `bool` | `true` | no |
| <a name="input_custom_name"></a> [custom\_name](#input\_custom\_name) | Set custom name for deployment. | `string` | `""` | no |
| <a name="input_custom_tags"></a> [custom\_tags](#input\_custom\_tags) | Set custom tags for deployment. | `map(string)` | `null` | no |
| <a name="input_dead_letter_target_arn"></a> [dead\_letter\_target\_arn](#input\_dead\_letter\_target\_arn) | The ARN of an SNS topic or SQS queue to notify when an invocation fails. | `string` | `null` | no |
| <a name="input_dry_run"></a> [dry\_run](#input\_dry\_run) | This flags determines if a ITSM Ticket is actually created or if only a dry\_run is performed against the ITSM API. | `bool` | n/a | yes |
| <a name="input_event_id"></a> [event\_id](#input\_event\_id) | Event ID, e.g. 80123. | `string` | `80123` | no |
| <a name="input_function_name"></a> [function\_name](#input\_function\_name) | The name of the lambda function for alerting purposes. | `string` | `"itsm"` | no |
| <a name="input_global_config"></a> [global\_config](#input\_global\_config) | Global config Object for the deployment which contains the mandatory informations within BMW, see https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/guidelines/terraform-modules/#mandatory-module-variables | <pre>object({<br>    env             = string<br>    customer_prefix = optional(string, "")<br>    product_id      = optional(string, "")<br>    appd_id         = string<br>    app_name        = string<br>    costcenter      = optional(string, "")<br>  })</pre> | n/a | yes |
| <a name="input_itsm_api_key"></a> [itsm\_api\_key](#input\_itsm\_api\_key) | ITSM API Key based on Cloud Self Service Portal - https://manage.aws.bmw.cloud/aws/index.html#itsm. | `string` | n/a | yes |
| <a name="input_itsm_api_url"></a> [itsm\_api\_url](#input\_itsm\_api\_url) | ITSM Event Bridge API URL https://atc.bmwgroup.net/confluence/display/DEVOPSPF/AWS+ITSM+Bridge | `string` | `"https://itsm-gateway.aws.bmw.cloud/v1/itsm"` | no |
| <a name="input_itsm_ticket_severity"></a> [itsm\_ticket\_severity](#input\_itsm\_ticket\_severity) | OK, WARNING, MINOR, MAJOR, CRITICAL. ITSM Severity of Tickets which are created - https://atc.bmwgroup.net/bitbucket/projects/FPCBMW/repos/aws-itsm-api/raw/src/create_itsm_ticket/itsm_schema.json | `string` | n/a | yes |
| <a name="input_kms_key_id_lambda"></a> [kms\_key\_id\_lambda](#input\_kms\_key\_id\_lambda) | (Optional) The ID of a customer managed KMS key to encrypt the lambda function and the CloudWatch logs. | `string` | `null` | no |
| <a name="input_kms_key_id_sns"></a> [kms\_key\_id\_sns](#input\_kms\_key\_id\_sns) | (Optional) The ID of a customer managed KMS key to encrypt the SNS topic. | `string` | `null` | no |
| <a name="input_lambda_failure_feedback_role_arn"></a> [lambda\_failure\_feedback\_role\_arn](#input\_lambda\_failure\_feedback\_role\_arn) | IAM role for failure feedback | `string` | `null` | no |
| <a name="input_lambda_success_feedback_role_arn"></a> [lambda\_success\_feedback\_role\_arn](#input\_lambda\_success\_feedback\_role\_arn) | The IAM role permitted to receive success feedback for this topic | `string` | `null` | no |
| <a name="input_lambda_success_feedback_sample_rate"></a> [lambda\_success\_feedback\_sample\_rate](#input\_lambda\_success\_feedback\_sample\_rate) | Percentage of success to sample | `string` | `null` | no |
| <a name="input_local_file_json_tpl"></a> [local\_file\_json\_tpl](#input\_local\_file\_json\_tpl) | Json Template file to override the local settings template. | `string` | `""` | no |
| <a name="input_monitoring_contract_id"></a> [monitoring\_contract\_id](#input\_monitoring\_contract\_id) | Monitoring Contract ID, e.g. 10APP12345678. | `string` | n/a | yes |
| <a name="input_naming_file_json_tpl"></a> [naming\_file\_json\_tpl](#input\_naming\_file\_json\_tpl) | Json Template file to override the Naming template. | `string` | `""` | no |
| <a name="input_origin"></a> [origin](#input\_origin) | The value for origin, e.g. APPD-12345. | `string` | n/a | yes |
| <a name="input_path_to_custom_lambda_files"></a> [path\_to\_custom\_lambda\_files](#input\_path\_to\_custom\_lambda\_files) | Path to folder where custom py and json are located | `string` | `null` | no |
| <a name="input_reserved_concurrent_executions"></a> [reserved\_concurrent\_executions](#input\_reserved\_concurrent\_executions) | (Optional) Amount of reserved concurrent executions for this lambda function. A value of 0 disables lambda from being triggered and -1 removes any concurrency limitations. Defaults to Unreserved Concurrency Limits -1. | `number` | `-1` | no |
| <a name="input_retention_in_days"></a> [retention\_in\_days](#input\_retention\_in\_days) | Specifies the number of days you want to retain log events in the specified log group. Possible values are: 1, 3, 5, 7, 14, 30, 60, 90, 120, 150, 180, 365, 400, 545, 731, 1827, 2192, 2557, 2922, 3288, 3653, and 0. If you select 0, the events in the log group are always retained and never expire. | `number` | `14` | no |
| <a name="input_sns_policy"></a> [sns\_policy](#input\_sns\_policy) | The fully-formed AWS policy as JSON | `string` | `""` | no |
| <a name="input_sns_topic_arn"></a> [sns\_topic\_arn](#input\_sns\_topic\_arn) | ARN of SNS topic to used when `create_sns_topic` is false | `string` | `null` | no |
| <a name="input_tracing_mode"></a> [tracing\_mode](#input\_tracing\_mode) | Tracing mode of the Lambda Function. Valid value can be either PassThrough or Active. | `string` | `null` | no |
| <a name="input_use_customer_key"></a> [use\_customer\_key](#input\_use\_customer\_key) | telling the module whether to encrypt its data with a customer managed KMS key or not | `bool` | `false` | no |
| <a name="input_vpc_security_group_ids"></a> [vpc\_security\_group\_ids](#input\_vpc\_security\_group\_ids) | List of security group ids when Lambda Function should run in the VPC. | `list(string)` | `null` | no |
| <a name="input_vpc_subnet_ids"></a> [vpc\_subnet\_ids](#input\_vpc\_subnet\_ids) | List of subnet ids when Lambda Function should run in the VPC. Usually private or intra subnets. | `list(string)` | `null` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cloudwatch_log_group_arn"></a> [cloudwatch\_log\_group\_arn](#output\_cloudwatch\_log\_group\_arn) | The Amazon Resource Name (ARN) specifying the log group. |
| <a name="output_cloudwatch_log_group_name"></a> [cloudwatch\_log\_group\_name](#output\_cloudwatch\_log\_group\_name) | Name of the cloudwatch log group |
| <a name="output_itsm_topic_arn"></a> [itsm\_topic\_arn](#output\_itsm\_topic\_arn) | SNS Topic ARN for ITSM. |
| <a name="output_lambda_function_arn"></a> [lambda\_function\_arn](#output\_lambda\_function\_arn) | The Amazon Resource Name (ARN) specifying the lambda function. |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
