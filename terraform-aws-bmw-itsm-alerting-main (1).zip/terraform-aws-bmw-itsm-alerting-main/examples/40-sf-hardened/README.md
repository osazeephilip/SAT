# SF hardened example: ITSM Ticket Service based on a Lambda function and an existing SNS Topic

<!--sf-eu-central-1-test-start-->
[![TF Base](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=TF%20Base&message=✓%203%20|✗%200%20|▲%201|➝%200&color=yellow)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-itsm-alerting/actions/runs/2348898)
[![TF Compliance (tflint)](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=TF%20Compliance%20(tflint)&message=✓%20Success&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-itsm-alerting/actions/runs/2348898)
[![Security (Checkov)](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=Security%20(Checkov)&message=✓%2054%20|✗%200%20|▲%209|➝%200&color=yellow)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-itsm-alerting/actions/runs/2348898)
[![TF Deploy](https://img.shields.io/static/v1?logo=terraform&style=plastic&label=TF%20Deploy&message=✓%206%20|✗%202%20|▲%200|➝%200&color=critical)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-itsm-alerting/actions/runs/2348898)
[![Inspec - aws](https://img.shields.io/static/v1?logo=chef&style=plastic&label=Inspec%20-%20aws&message=✓%20Success&color=success)](https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-itsm-alerting/actions/runs/2348898)
<!--sf-eu-central-1-test-end-->

This template helps to create ITSM incident tickets based on Cloudwatch alarms or events originating from your AWS account.

This example sets up a Lambda function, while the ARN of an existing SNS Topic is just handed over.

You have to setup your CloudWatch events/alarms and configure forwarding to the SNS Topic.

If the topic receives messages they are forwarded to a Lamdbda function.
The Lambda function holds your ITSM configuration, parses the events/alarm messages and triggers the [AWS ITSM Event Bridge API](https://developer.bmwgroup.net/docs/public-cloud-platform-aws/3_runyourapplication/monitoring_and_alerting/itsm_gateway/itsm_gateway/#overview) which is provided by the BMW FPC Team.

In addition, this example shows how a kms key can be created and used for this module. For further reading look at <https://aws.amazon.com/blogs/compute/encrypting-messages-published-to-amazon-sns-with-aws-kms/>

# Prerequisites
- Fully configured BMW AWS Cloud Room
- Service Principal for this Cloud Room
- Latest Terraform Version (>= 1.1.5) [Download](https://www.terraform.io/downloads)
- Possibility to run Bash scripts (Linux OS, WSL2, Cygwin)
- You have read the READMEs and the comments in main.tf and variables.tfvars
- You have adjusted the configuration to **your** cloud room
- There is an SNS topic existing in your cloudroom with an access policy allowing your message source to submit events. (see example policy below)

## Architecture

![AWS Architecture Diagram](../../images/aws-sns-lambda-itsm.png)

## Created Resources

**AWS Region** : eu-central-1 (Frankfurt)

-   AWS Lambda
-   AWS KMS Key

## How to configure the module for this scenario

### Using an external SNS topic
To use an SNS topic not created with your deployment, please:
- set `create_sns_topic = false`
- set `sns_topic_arn = "<arnOfAnExistingSnsTopic"`
- Take care of this SNS topic's access policy. In case you are going to use Cloudwatch as an event source, your policy document might look like this:
```
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "Allow_Publish_Alarms",
      "Effect": "Allow",
      "Principal": {
        "Service": "cloudwatch.amazonaws.com"
      },
      "Action": "sns:Publish",
      "Resource": "arn:aws:sns:eu-central-1:<yourAwsAccountID>:*"
    }
  ]
}
```

### Use customer managed KMS keys
The module enables you to use up to two different customer managed KMS keys. Following configuration options are supported:
- no CMK KMS key at all:
  - Set `use_customer_key` to `false` (which is default).
  - Don't hand over a KMS key ID.
- One customer managed KMS key for all resources:
  - Set `use_customer_key` to `true`.
  - Hand over the same KMS key id to both variables, `kms_key_id_lambda` and `kms_key_id_sns`.
- Two different customer managed KMS keys:
  - Set `use_customer_key` to `true`.
  - Hand over the first KMS key id to `kms_key_id_lambda`.
  - Hand over the second KMS key id to `kms_key_id_sns`.

### Preparation: Monitoring Contract ID and ITSM Bridge Configuration

-   An Monitoring Contract ID (MCID) has to be created for your ITSM service. This ID is linked to your existing ITSM service and allows you to programatically create ITSM tickets. See ["Where can I find my monitoring "contract_id" and "event_id"?](https://developer.bmwgroup.net/docs/public-cloud-platform-aws/3_runyourapplication/monitoring_and_alerting/itsm_gateway/itsm_gateway/#where-can-i-find-my-monitoring-contract-id-and-event-id) on how to create the contract.  
-   An API Endpoint for accessing the ITSM bridge has to be created in the [AWS Customer Portal](https://manage.aws.bmw.cloud/). See ["Create a new ITSM Gateway API key"](https://developer.bmwgroup.net/docs/public-cloud-platform-aws/3_runyourapplication/monitoring_and_alerting/itsm_gateway/itsm_gateway/#create-a-new-itsm-gateway-api-key) how to create the endpoint and check your account-specific API key.

### IaC Depoyment: aws-sns-lambda-itsm

The input variables of the template are all set as ENV variables in the Lambda function.
When the Lambda function triggers the ITSM Bridge several variables are needed for the HTTP POST. Some variables are parsed from the Cloudwatch event/alarm, for other (more static) variables the ENVs of the Lambda are used.

Make sure to set the aws profile of your cloud room, e.g. `XXXXXXXXXXXX_UserFull`.

### Further notes

**Regarding ticket deduplication**: As written in the [ITSM Bridge documentation](https://developer.bmwgroup.net/docs/public-cloud-platform-aws/3_runyourapplication/monitoring_and_alerting/itsm_gateway/itsm_gateway/#how-to-handle-ticket-deduplication) a set of several variables are used to identify a possible duplicate ticket. Depending on the application and events/alarms, the incrementation of the `event_id` variable in the lambda function or the usage of other fields like `dd` has to be considered.

**Regarding ticket severity**: Several different ticket severities do exist, see [ITSM Bridge documentation](https://developer.bmwgroup.net/docs/public-cloud-platform-aws/3_runyourapplication/monitoring_and_alerting/itsm_gateway/itsm_gateway/#how-can-i-modify-the-impact-urgency-and-priority-in-itsm). In order to use this template and create tickets with different severities you can

-   create different Lambda functions with different severities in their ENV or
-   adjust the code of the Lambda function and use a severity based on our event/alarm parsing.

**FAQ**: [ITSM Gateway > FAQ](https://developer.bmwgroup.net/docs/public-cloud-platform-aws/3_runyourapplication/monitoring_and_alerting/itsm_gateway/itsm_gateway/#faq)
