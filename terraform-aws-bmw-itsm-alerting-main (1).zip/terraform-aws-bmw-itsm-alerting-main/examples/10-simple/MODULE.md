# 10-simple

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.3 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | ~> 4 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | 4.67.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_common"></a> [common](#module\_common) | git::https://atc-github.azure.cloud.bmw/cgbp/terraform-bmw-cloud-commons.git | 2.1.7 |
| <a name="module_itsm_alerting"></a> [itsm\_alerting](#module\_itsm\_alerting) | ../../ | n/a |
| <a name="module_kms_key"></a> [kms\_key](#module\_kms\_key) | git::https://atc-github.azure.cloud.bmw/cgbp/terraform-aws-bmw-kms | 3.0.2 |

## Resources

| Name | Type |
|------|------|
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_iam_policy_document.cloudwatch](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_partition.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/partition) | data source |
| [aws_region.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/region) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cloud_region"></a> [cloud\_region](#input\_cloud\_region) | define the location which tf should use. | `string` | n/a | yes |
| <a name="input_global_config"></a> [global\_config](#input\_global\_config) | Global config Object for the deployment which contains the mandatory informations within BMW, see https://developer.bmw.com/docs/cloud-guides-and-best-practices/20_gettingstarted/guidelines/terraform-modules/#mandatory-module-variables | <pre>object({<br>    env             = string<br>    customer_prefix = optional(string, "")<br>    product_id      = optional(string, "")<br>    appd_id         = string<br>    app_name        = string<br>    costcenter      = optional(string, "")<br>  })</pre> | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cloudwatch_log_group_arn"></a> [cloudwatch\_log\_group\_arn](#output\_cloudwatch\_log\_group\_arn) | The Amazon Resource Name (ARN) specifying the log group. |
| <a name="output_cloudwatch_log_group_name"></a> [cloudwatch\_log\_group\_name](#output\_cloudwatch\_log\_group\_name) | Name of the cloudwatch log group |
| <a name="output_itsm_alerting_sns_topic_arn"></a> [itsm\_alerting\_sns\_topic\_arn](#output\_itsm\_alerting\_sns\_topic\_arn) | The ARN of the SNS topic |
| <a name="output_kms_key_arn"></a> [kms\_key\_arn](#output\_kms\_key\_arn) | The ARN of the KMS key used as CMK on the SNS topic |
| <a name="output_kms_key_id"></a> [kms\_key\_id](#output\_kms\_key\_id) | The ID of the KMS key used as CMK on the SNS topic |
| <a name="output_lambda_function_arn"></a> [lambda\_function\_arn](#output\_lambda\_function\_arn) | The Amazon Resource Name (ARN) specifying the lambda function. |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
