# # load data from Terraform output
content = inspec.profile.file("outputs.json.local")
params = JSON.parse(content)
# # # Get outputs
cloudwatch_log_group_name = params['cloudwatch_log_group_name']['value']
itsm_alerting_sns_topic_arn = params['itsm_alerting_sns_topic_arn']['value']
kms_key_id = params['kms_key_id']['value']
lambda_function_arn = params['lambda_function_arn']['value']

title "CNA Inspec Test"

control 'Cloud Region' do
  impact 1.0
title "Check Input from example deployment."
desc "Check necessary Input parameter CLOUD_REGION"
  describe input('CLOUD_REGION') do    # This line reads the value of the input
    it { should be_in ['eu-central-1', 'eu-west-1', 'us-east-1'] }
  end
end

control 'Alerting Outputs' do
  impact 1.0
  title "Check Alerting deployment"
  desc "Check outputs from example & deployment of Alerting"
  describe aws_sns_topic(arn: itsm_alerting_sns_topic_arn) do
    it { should exist }
    its ('kms_master_key_id') { should eq kms_key_id}
  end
  describe aws_cloudwatch_log_group(cloudwatch_log_group_name) do
    it { should exist }
  end
  describe aws_lambda(lambda_function_arn) do
    it { should exist }
  end
end
