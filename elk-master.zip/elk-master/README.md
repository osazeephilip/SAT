# Installing Elastic Stack (ELK) 7.x on OpenShift

Instructions for installing Elastic Stack 7 on OpenShift

* [Preparations](elk7-0-preparations.md)
* [Elasticsearch](elk-elasticsearch.md)
* [Logstash](elk-logstash.md)
* [Kibana](elk7-3-kibana.md)
